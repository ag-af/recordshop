package com.northcoders.recordshop.model;

public enum Genre {
    CLASSICAL,
    JAZZ,
    BLUES,
    BOSSA_NOVA,
    POP,
    ROCK,
    HIPHOP,
    CHRISTMAS,
    ELECTRONIC,
    GOSPEL,
    MPB,
    REGGAE,
    SAMBA,
}