package com.northcoders.recordshop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RecordShopApiMiniProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(RecordShopApiMiniProjectApplication.class, args);
	}

}
