package com.northcoders.recordshop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RecordShopApiMiniProjectApplicationTests {

	@Test
	void contextLoads() {
	}
}
